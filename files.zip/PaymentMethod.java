package eci.edu.byteProgramming.ejercicio.paper.util;

import java.util.Date;

public abstract class PaymentMethod implements ValidatePayment {
    protected double amount;
    protected String transactionID;
    protected String customerID;   // campo interno
    protected String currency;
    protected Date timestamp;
    protected PaymentStatus status;
    protected String description;

    /**
     * CORRECCIÓN: el segundo parámetro era "transactionID" (copia del nombre del campo),
     * por lo que customerID nunca recibía el valor y quedaba null.
     * Se renombra a customerId para que la asignación sea correcta.
     */
    public PaymentMethod(double amount, String customerId, String description) {
        this.amount = amount;
        this.customerID = customerId;          // ← fix: antes era "customerID = customerID" → null
        this.description = description;
        this.currency = "USD";
        this.status = PaymentStatus.PENDING;
        this.timestamp = new Date();
        this.transactionID = generateTransactionId();
    }

    public abstract boolean processPayment();
    public abstract String getPaymentMethod();

    protected String generateTransactionId() {
        long ts = System.currentTimeMillis();
        int random = (int)(Math.random() * 9999);
        return String.format("TXN%d%04d", ts, random);
    }

    protected String generateTransactionIdWithPrefix(String paymentType) {
        String prefix = getPaymentTypePrefix(paymentType);
        long ts = System.currentTimeMillis();
        int random = (int)(Math.random() * 9999);
        return String.format("%s%d%04d", prefix, ts, random);
    }

    private String getPaymentTypePrefix(String paymentType) {
        switch (paymentType) {
            case "CREDIT_CARD": return "CC";
            case "PAYPAL":      return "PP";
            case "CRYPTO":      return "CR";
            default:            return "TX";
        }
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getAmount()            { return amount; }
    public String getTransactionId()     { return transactionID; }
    public PaymentStatus getStatus()     { return status; }
    public void setStatus(PaymentStatus status) { this.status = status; }
    public String getCustomerId()        { return customerID; }
    public String getDescription()       { return description; }
    public Date getTimestamp()           { return timestamp; }
}
