package eci.edu.byteProgramming.ejercicio.paper.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias del sistema de pagos.
 * Verifican: Abstract Factory (crear métodos de pago) + Observer (notificaciones).
 */
public class PaymentSystemTest {

    private ECIPayment eciPayment;
    private Inventory inventory;
    private Facturation facturation;
    private Notification notification;

    @BeforeEach
    void setUp() {
        inventory    = new Inventory();
        facturation  = new Facturation();
        notification = new Notification();

        eciPayment = new ECIPayment();
        eciPayment.addObserver(new InventoryObserver(inventory));
        eciPayment.addObserver(new FacturationObserver(facturation, inventory));
        eciPayment.addObserver(new NotificationObserver(notification));
    }

    // ── Abstract Factory ──────────────────────────────────────────────────────

    @Test
    void creditCardFactory_createsValidPaymentMethod() {
        PaymentFactory factory = new CreditCardFactory(
                "4111111111111111", "John Doe", "12/26", "123", "Calle 100");

        PaymentMethod payment = factory.createPaymentMethod(500.0, "CUST001", "Gaming Laptop");

        assertNotNull(payment);
        assertEquals(500.0, payment.getAmount());
        assertEquals("CUST001", payment.getCustomerId());   // verifica fix del constructor
        assertEquals("CREDIT_CARD", payment.getPaymentMethod());
        assertTrue(payment.validatePaymentMethod());
    }

    @Test
    void paypalFactory_createsValidPaymentMethod() {
        PaymentFactory factory = new PaypalFactory("user@example.com", "VALID_TOKEN_12345");

        PaymentMethod payment = factory.createPaymentMethod(200.0, "CUST002", "Smartphone");

        assertNotNull(payment);
        assertEquals(200.0, payment.getAmount());
        assertEquals("CUST002", payment.getCustomerId());
        assertEquals("PAYPAL", payment.getPaymentMethod());
        assertTrue(payment.validatePaymentMethod());
    }

    @Test
    void cryptoFactory_createsValidPaymentMethod() {
        String wallet = "0xABCDEF1234567890ABCDEF1234567890"; // >= 26 chars
        PaymentFactory factory = new CryptoFactory(wallet, "ETH", 5000.0);

        PaymentMethod payment = factory.createPaymentMethod(300.0, "CUST003", "Book");

        assertNotNull(payment);
        assertEquals(300.0, payment.getAmount());
        assertEquals("CUST003", payment.getCustomerId());
        assertEquals("CRYPTOCURRENCY", payment.getPaymentMethod());
        assertTrue(payment.validatePaymentMethod());
    }

    // ── Validaciones ──────────────────────────────────────────────────────────

    @Test
    void creditCard_invalidCVV_failsValidation() {
        CreditCardFactory cc = new CreditCardFactory(
                100.0, "C1", "Test",
                "4111111111111111", "Jane", "12/26", "12", "Addr"); // CVV de 2 dígitos
        assertFalse(cc.validatePaymentMethod());
    }

    @Test
    void paypal_invalidEmail_failsValidation() {
        PaypalFactory pp = new PaypalFactory(100.0, "C2", "Test", "not-an-email", "VALID_TOKEN_123");
        assertFalse(pp.validatePaymentMethod());
    }

    @Test
    void crypto_insufficientBalance_failsValidation() {
        String wallet = "0xABCDEF1234567890ABCDEF1234567890";
        CryptoFactory cf = new CryptoFactory(9999.0, "C3", "Test", wallet, "BTC", 10.0);
        assertFalse(cf.validatePaymentMethod()); // balance < amount
    }

    // ── Observer / integración ────────────────────────────────────────────────

    @Test
    void successfulPayment_discountsInventory() {
        int stockBefore = inventory.getStock("LAPTOP001");

        PaymentFactory factory = new CreditCardFactory(
                "4111111111111111", "Ana García", "12/26", "321", "Cra 7");

        eciPayment.processPayment(factory, 1200.0, "CUST010",
                "Gaming Laptop", "Ana García", "ana@test.com", "LAPTOP001");

        assertEquals(stockBefore - 1, inventory.getStock("LAPTOP001"));
    }

    @Test
    void paymentStatus_isPending_beforeProcessing() {
        PaymentFactory factory = new PaypalFactory("ok@ok.com", "VALID_TOKEN_XYZ99");
        PaymentMethod payment = factory.createPaymentMethod(50.0, "CUST011", "Book");
        assertEquals(PaymentStatus.PENDING, payment.getStatus());
    }

    @Test
    void eciPayment_canAddAndRemoveObservers() {
        ECIPayment ep = new ECIPayment();
        InventoryObserver obs = new InventoryObserver(new Inventory());

        ep.addObserver(obs);
        ep.removeObserver(obs);
        // No debe lanzar excepción al procesar sin observadores
        PaymentFactory factory = new PaypalFactory("x@x.com", "TOKEN_INVALIDO"); // fallará validación
        assertDoesNotThrow(() ->
                ep.processPayment(factory, 10.0, "C99", "desc", "Name", "x@x.com", "BOOK001"));
    }
}
