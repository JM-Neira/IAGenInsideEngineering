package eci.edu.byteProgramming.ejercicio.paper.util;

public class CryptoFactory extends PaymentMethod implements PaymentFactory {

    private String walletAddress;
    private String cryptoType;
    private double walletBalance;
    private String blockchainHash;
    // CORRECCIÓN: se eliminó el campo "token" porque no llegaba como parámetro
    // y se auto-asignaba null. Si se necesita en el futuro, debe agregarse al constructor.

    public CryptoFactory(double amount, String customerId, String description,
                         String walletAddress, String cryptoType, double walletBalance) {
        super(amount, customerId, description);
        this.walletAddress = walletAddress;
        this.cryptoType = cryptoType;
        this.walletBalance = walletBalance;
    }

    /** Constructor de factory: solo guarda credenciales de wallet */
    public CryptoFactory(String walletAddress, String cryptoType, double walletBalance) {
        super(0, null, null);
        this.walletAddress = walletAddress;
        this.cryptoType = cryptoType;
        this.walletBalance = walletBalance;
    }

    @Override
    public PaymentMethod createPaymentMethod(double amount, String customerId, String description) {
        return new CryptoFactory(amount, customerId, description,
                walletAddress, cryptoType, walletBalance);
    }

    @Override
    public boolean validatePaymentMethod() {
        return validateWalletAddress() && validateBalance();
    }

    private boolean validateWalletAddress() {
        return walletAddress != null && walletAddress.length() >= 26;
    }

    private boolean validateBalance() {
        return walletBalance >= amount;
    }

    @Override
    public boolean processPayment() {
        System.out.println("Processing Cryptocurrency payment...");
        if (!validatePaymentMethod()) {
            System.out.println("Crypto validation failed!");
            setStatus(PaymentStatus.FAILED);
            return false;
        }
        setStatus(PaymentStatus.PROCESSING);
        try {
            Thread.sleep(3000);
            this.blockchainHash = generateBlockchainHash();
            System.out.println("Transaction broadcasted to blockchain");
            System.out.println("Blockchain hash: " + blockchainHash);
            setStatus(PaymentStatus.COMPLETED);
            return true;
        } catch (Exception e) {
            setStatus(PaymentStatus.FAILED);
            return false;
        }
    }

    @Override
    public String getPaymentMethod() { return "CRYPTOCURRENCY"; }

    private String generateBlockchainHash() {
        return "0x" + Integer.toHexString((int)(Math.random() * Integer.MAX_VALUE));
    }

    public String getWalletAddress()  { return walletAddress; }
    public String getCryptoType()     { return cryptoType; }
    public String getBlockchainHash() { return blockchainHash; }
}
