package eci.edu.byteProgramming.ejercicio.paper.util;

/**
 * Abstract Factory interface.
 * Cada implementación concreta sabe cómo crear su propio PaymentMethod
 * con los datos específicos de ese medio de pago.
 * ECIPayment trabaja solo con esta interfaz, sin conocer los detalles internos.
 */
public interface PaymentFactory {
    PaymentMethod createPaymentMethod(double amount, String customerId, String description);
}
