package eci.edu.byteProgramming.ejercicio.paper.util;

// ─────────────────────────────────────────────────────────────────────────────
// 1. InventoryObserver
//    Adapta Inventory al contrato PaymentObserver.
//    Cuando el pago es exitoso, descuenta 1 unidad del producto comprado.
// ─────────────────────────────────────────────────────────────────────────────
class InventoryObserver implements PaymentObserver {

    private final Inventory inventory;

    public InventoryObserver(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public void onPaymentSuccess(PaymentMethod payment, String customerName,
                                 String customerEmail, String productId) {
        System.out.println("📦 InventoryObserver: discounting product " + productId);
        inventory.discountProduct(productId, 1);
    }

    @Override
    public void onPaymentFailed(PaymentMethod payment, String customerEmail) {
        System.out.println("📦 InventoryObserver: payment failed — no stock change for " + customerEmail);
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 2. FacturationObserver
//    Adapta Facturation al contrato PaymentObserver.
//    Cuando el pago es exitoso, genera la factura correspondiente.
// ─────────────────────────────────────────────────────────────────────────────
class FacturationObserver implements PaymentObserver {

    private final Facturation facturation;
    private final Inventory inventory;

    public FacturationObserver(Facturation facturation, Inventory inventory) {
        this.facturation = facturation;
        this.inventory = inventory;
    }

    @Override
    public void onPaymentSuccess(PaymentMethod payment, String customerName,
                                 String customerEmail, String productId) {
        Product product = inventory.getProduct(productId);
        String productDetails = (product != null)
                ? product.getName() + " (" + productId + ")"
                : productId;

        System.out.println("📄 FacturationObserver: generating invoice for " + customerName);
        facturation.generateInvoice(payment, customerName, productDetails);
    }

    @Override
    public void onPaymentFailed(PaymentMethod payment, String customerEmail) {
        System.out.println("📄 FacturationObserver: payment failed — no invoice for " + customerEmail);
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 3. NotificationObserver
//    Adapta Notification al contrato PaymentObserver.
//    Envía confirmación o aviso de fallo al correo del cliente.
// ─────────────────────────────────────────────────────────────────────────────
class NotificationObserver implements PaymentObserver {

    private final Notification notification;

    public NotificationObserver(Notification notification) {
        this.notification = notification;
    }

    @Override
    public void onPaymentSuccess(PaymentMethod payment, String customerName,
                                 String customerEmail, String productId) {
        System.out.println("📧 NotificationObserver: sending confirmation to " + customerEmail);
        notification.sendConfirmationEmail(customerEmail, customerName, payment);
    }

    @Override
    public void onPaymentFailed(PaymentMethod payment, String customerEmail) {
        System.out.println("📧 NotificationObserver: sending failure notice to " + customerEmail);
        notification.sendFailureNotification(payment, customerEmail);
    }
}
