package eci.edu.byteProgramming.ejercicio.paper.util;

/**
 * Producto concreto de tarjeta de crédito + fábrica concreta del patrón Abstract Factory.
 *
 * Para usarla como factory se instancia con los datos específicos de tarjeta
 * y se pasa al ECIPayment, que luego llama createPaymentMethod(...).
 */
public class CreditCardFactory extends PaymentMethod implements PaymentFactory {

    private String number;
    private String name;
    private String expirationDate;
    private String cvv;
    private String cardType;
    private String address;

    // Constructor completo (uso directo o interno desde createPaymentMethod)
    public CreditCardFactory(double amount, String customerId, String description,
                             String number, String name, String expirationDate,
                             String cvv, String address) {
        super(amount, customerId, description);
        this.number = number;
        this.name = name;
        this.expirationDate = expirationDate;
        this.cvv = cvv;
        this.address = address;
        this.cardType = determineCardType(number);
    }

    /**
     * Constructor de factory (guarda los datos de tarjeta para usarlos al crear el método).
     * Se construye sin amount/customerId/description porque esos llegan en createPaymentMethod.
     */
    public CreditCardFactory(String number, String name, String expirationDate,
                             String cvv, String address) {
        super(0, null, null);
        this.number = number;
        this.name = name;
        this.expirationDate = expirationDate;
        this.cvv = cvv;
        this.address = address;
        this.cardType = determineCardType(number);
    }

    /** Patrón Abstract Factory: crea el PaymentMethod concreto con los datos de la compra */
    @Override
    public PaymentMethod createPaymentMethod(double amount, String customerId, String description) {
        return new CreditCardFactory(amount, customerId, description,
                number, name, expirationDate, cvv, address);
    }

    @Override
    public boolean validatePaymentMethod() {
        return validateCardNumber() && validateCVV() && validateExpirationDate();
    }

    private boolean validateCardNumber() {
        return number != null && number.length() >= 13 && number.length() <= 19;
    }

    private boolean validateCVV() {
        return cvv != null && cvv.length() >= 3 && cvv.length() <= 4;
    }

    private boolean validateExpirationDate() {
        return expirationDate != null && expirationDate.matches("\\d{2}/\\d{2}");
    }

    @Override
    public boolean processPayment() {
        System.out.println("Processing Credit Card payment...");
        if (!validatePaymentMethod()) {
            System.out.println("Credit Card validation failed!");
            setStatus(PaymentStatus.FAILED);
            return false;
        }
        setStatus(PaymentStatus.PROCESSING);
        try {
            Thread.sleep(2000);
            System.out.println("Contacting bank for card: " + maskCardNumber());
            System.out.println("Payment authorized by bank");
            setStatus(PaymentStatus.COMPLETED);
            return true;
        } catch (Exception e) {
            setStatus(PaymentStatus.FAILED);
            return false;
        }
    }

    @Override
    public String getPaymentMethod() { return "CREDIT_CARD"; }

    private String determineCardType(String cardNumber) {
        if (cardNumber == null) return "UNKNOWN";
        if (cardNumber.startsWith("4")) return "VISA";
        if (cardNumber.startsWith("5")) return "MASTERCARD";
        if (cardNumber.startsWith("3")) return "AMEX";
        return "UNKNOWN";
    }

    public String maskCardNumber() {
        return "**** **** **** " + number.substring(number.length() - 4);
    }

    public String getCardHolderName() { return name; }
    public String getCardType()       { return cardType; }
}
